extends Node3D

# İstanbul City - tek sahnede çalışan, mobil odaklı 3B açık dünya prototipi.
# Görsel varlıklar çalışma anında düşük maliyetli mesh'lerle üretilir.

const PLAYER_SPEED := 5.2
const SPRINT_SPEED := 8.2
const CAR_ACCEL := 18.0
const CAR_MAX_SPEED := 27.0
const CITY_LIMIT := 155.0

var player: CharacterBody3D
var player_visual: Node3D
var car: CharacterBody3D
var car_visual: Node3D
var camera: Camera3D
var world_environment: WorldEnvironment
var hud: CanvasLayer
var joystick := Vector2.ZERO
var sprinting := false
var crouching := false
var jumping := false
var driving := false
var throttle := 0.0
var steering := 0.0
var handbrake := false
var car_speed := 0.0
var car_yaw := 0.0
var camera_yaw := 0.0
var camera_pitch := -0.18
var camera_drag := false
var last_touch := Vector2.ZERO
var joystick_touch_index := -1
var camera_touch_index := -1
var health := 100.0
var money := 5000
var wanted := 0
var mission_stage := 0
var mission_text := "Sarı taksiye yaklaş ve araca bin"
var clock := 0.0
var traffic_nodes: Array[Dictionary] = []
var pedestrian_nodes: Array[Dictionary] = []
var police_nodes: Array[Dictionary] = []
var building_boxes: Array[AABB] = []
var ui_label: Label
var mission_label: Label
var speed_label: Label
var action_button: Button
var interact_button: Button
var touch_buttons: Dictionary = {}
var joystick_center := Vector2(118, 0)
var joystick_radius := 86.0

func _ready() -> void:
	_build_environment()
	_build_city()
	_build_player()
	_build_car()
	_build_people_and_traffic()
	_build_camera()
	_build_hud()
	_update_hud()

func _process(delta: float) -> void:
	clock += delta
	_update_people(delta)
	_update_traffic(delta)
	_update_police(delta)
	_update_camera(delta)
	_update_mission()
	_update_hud()

func _physics_process(delta: float) -> void:
	if driving:
		_update_car(delta)
	else:
		_update_player(delta)

func _mat(color: Color, roughness := 0.82, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _mesh_box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, name := "Box") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = name
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

func _mesh_cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, name := "Cylinder") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = name
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

func _mesh_sphere(parent: Node3D, pos: Vector3, radius: float, material: Material, name := "Sphere") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = name
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 16
	mesh.rings = 8
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

func _static_box(pos: Vector3, size: Vector3, material: Material, label := "Building") -> void:
	var body := StaticBody3D.new()
	body.name = label
	body.position = pos
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	_mesh_box(body, Vector3.ZERO, size, material)
	add_child(body)
	building_boxes.append(AABB(pos - size * 0.5, size))

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.12, 0.34, 0.62)
	sky_mat.sky_horizon_color = Color(0.68, 0.78, 0.86)
	sky_mat.ground_bottom_color = Color(0.19, 0.20, 0.22)
	sky_mat.ground_horizon_color = Color(0.52, 0.58, 0.62)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.68, 0.78)
	env.ambient_light_energy = 0.72
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.68, 0.75, 0.81)
	env.fog_density = 0.0018
	world_environment = WorldEnvironment.new()
	world_environment.environment = env
	add_child(world_environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_color = Color(1.0, 0.88, 0.72)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 95.0
	add_child(sun)

func _build_city() -> void:
	var asphalt := _mat(Color(0.105, 0.12, 0.14), 0.96)
	var sidewalk := _mat(Color(0.48, 0.49, 0.47))
	var curb := _mat(Color(0.72, 0.71, 0.66))
	var line_mat := _mat(Color(0.92, 0.83, 0.48), 0.7)
	var white := _mat(Color(0.88, 0.88, 0.83), 0.72)
	var glass := _mat(Color(0.075, 0.18, 0.26), 0.22, 0.35)
	var facade_mats: Array[Material] = [
		_mat(Color(0.58, 0.48, 0.39)), _mat(Color(0.68, 0.64, 0.56)),
		_mat(Color(0.42, 0.46, 0.49)), _mat(Color(0.72, 0.57, 0.46)),
		_mat(Color(0.52, 0.53, 0.49))]
	_mesh_box(self, Vector3(0, -0.42, 0), Vector3(330, 0.5, 330), _mat(Color(0.24, 0.31, 0.25)), "Ground")
	var ground_body := StaticBody3D.new()
	ground_body.name = "GroundCollision"
	ground_body.position = Vector3(0, -0.42, 0)
	var ground_shape := CollisionShape3D.new()
	var ground_box := BoxShape3D.new()
	ground_box.size = Vector3(330, 0.5, 330)
	ground_shape.shape = ground_box
	ground_body.add_child(ground_shape)
	add_child(ground_body)
	# Main boulevards and cross streets.
	for z in [-90.0, -45.0, 0.0, 45.0, 90.0]:
		_mesh_box(self, Vector3(0, -0.12, z), Vector3(330, 0.16, 17), asphalt, "AsphaltRoad")
		_mesh_box(self, Vector3(0, -0.025, z - 8.9), Vector3(330, 0.25, 2.8), sidewalk, "Sidewalk")
		_mesh_box(self, Vector3(0, -0.025, z + 8.9), Vector3(330, 0.25, 2.8), sidewalk, "Sidewalk")
		_mesh_box(self, Vector3(0, -0.015, z - 7.35), Vector3(330, 0.22, 0.22), curb, "Curb")
		_mesh_box(self, Vector3(0, -0.015, z + 7.35), Vector3(330, 0.22, 0.22), curb, "Curb")
		for x in range(-150, 151, 12):
			_mesh_box(self, Vector3(float(x), -0.025, z), Vector3(5.0, 0.025, 0.16), line_mat, "LaneMark")
	for x in [-90.0, -45.0, 0.0, 45.0, 90.0]:
		_mesh_box(self, Vector3(x, -0.12, 0), Vector3(17, 0.16, 330), asphalt, "CrossStreet")
		_mesh_box(self, Vector3(x - 8.9, -0.025, 0), Vector3(2.8, 0.25, 330), sidewalk, "Sidewalk")
		_mesh_box(self, Vector3(x + 8.9, -0.025, 0), Vector3(2.8, 0.25, 330), sidewalk, "Sidewalk")
		for z in range(-150, 151, 12):
			_mesh_box(self, Vector3(x, -0.025, float(z)), Vector3(0.16, 0.025, 5.0), white, "LaneMark")
	# Crosswalks on the central intersections.
	for z in [-45.0, 0.0, 45.0]:
		for i in range(8):
			_mesh_box(self, Vector3(-6.8 + i * 1.9, -0.015, z - 6.0), Vector3(1.0, 0.035, 3.2), white, "CrosswalkStripe")
	# Buildings, windows, storefronts, balconies, signs.
	var rng := RandomNumberGenerator.new()
	rng.seed = 44931
	for bx in range(-3, 4):
		for bz in range(-3, 4):
			if abs(bx) <= 1 and abs(bz) <= 1:
				continue
			var center := Vector3(float(bx) * 45.0 + 21.0, 0, float(bz) * 45.0 + 21.0)
			var w := rng.randf_range(17, 24)
			var d := rng.randf_range(17, 23)
			var floors := rng.randi_range(3, 7)
			var h := float(floors) * 3.2
			var facade: Material = facade_mats[rng.randi_range(0, facade_mats.size() - 1)]
			_static_box(center + Vector3(0, h * 0.5, 0), Vector3(w, h, d), facade, "IstanbulApartment")
			for floor in range(floors):
				for col in range(3):
					var wx := -w * 0.32 + float(col) * w * 0.32
					var wy := 1.15 + float(floor) * 3.2
					_mesh_box(self, center + Vector3(wx, wy, -d * 0.505), Vector3(2.1, 1.65, 0.12), glass, "Window")
					_mesh_box(self, center + Vector3(wx, wy - 0.92, -d * 0.51), Vector3(2.35, 0.12, 0.3), curb, "WindowSill")
					if floor > 0:
					_mesh_box(self, center + Vector3(wx, wy + 0.85, -d * 0.53), Vector3(2.3, 0.08, 0.7), _mat(Color(0.24, 0.25, 0.25)), "BalconyRail")
			# Street-level shopfront and bright Turkish sign.
			_mesh_box(self, center + Vector3(0, 1.15, -d * 0.515), Vector3(w * 0.72, 2.15, 0.16), glass, "ShopWindow")
			var sign_color := [Color(0.72, 0.12, 0.10), Color(0.10, 0.32, 0.27), Color(0.12, 0.19, 0.28)][rng.randi_range(0, 2)]
			_mesh_box(self, center + Vector3(0, 2.75, -d * 0.54), Vector3(w * 0.78, 0.72, 0.22), _mat(sign_color), "ShopSign")
	# Park squares and trees.
	for p in [Vector3(-18,0,-18), Vector3(18,0,-18), Vector3(-18,0,18), Vector3(18,0,18), Vector3(-65,0,18), Vector3(65,0,-18)]:
		_mesh_box(self, p + Vector3(0, 0.08, 0), Vector3(12, 0.2, 9), _mat(Color(0.25, 0.36, 0.25)), "PocketPark")
		for i in range(3):
			var tree_pos := p + Vector3(-3.8 + i * 3.8, 0, 0)
			_mesh_cylinder(self, tree_pos + Vector3(0, 1.4, 0), 0.22, 2.8, _mat(Color(0.25, 0.15, 0.08)), "TreeTrunk")
			_mesh_sphere(self, tree_pos + Vector3(0, 3.2, 0), 1.65, _mat(Color(0.08, 0.29, 0.15)), "TreeCanopy")
	# Street lamps and benches.
	for x in range(-120, 121, 30):
		for z in [-11.0, 11.0]:
			_mesh_cylinder(self, Vector3(float(x), 3.1, z), 0.12, 6.2, _mat(Color(0.15, 0.17, 0.18), 0.35, 0.55), "StreetLamp")
			_mesh_box(self, Vector3(float(x), 6.15, z - 0.45), Vector3(1.1, 0.16, 0.65), _mat(Color(1.0, 0.83, 0.54), 0.25), "LampGlow")
	# Landmark mosque at the far end of the avenue.
	_build_mosque(Vector3(0, 0, -118))
	# Traffic signals.
	for x in [-10.0, 10.0]:
		_mesh_cylinder(self, Vector3(x, 3.0, -8.2), 0.11, 6.0, _mat(Color(0.16,0.17,0.18)), "TrafficPole")
		_mesh_box(self, Vector3(x, 5.1, -8.2), Vector3(0.65, 1.65, 0.45), _mat(Color(0.06,0.07,0.07)), "TrafficSignal")
		_mesh_sphere(self, Vector3(x, 5.55, -7.94), 0.17, _mat(Color(0.12,0.85,0.25)), "GreenLight")

func _build_mosque(origin: Vector3) -> void:
	var stone := _mat(Color(0.78, 0.73, 0.63))
	var roof := _mat(Color(0.20, 0.23, 0.27), 0.4, 0.25)
	var gold := _mat(Color(0.83, 0.62, 0.22), 0.35, 0.55)
	_static_box(origin + Vector3(0, 5, 0), Vector3(25, 10, 19), stone, "MosqueMainHall")
	_mesh_cylinder(self, origin + Vector3(0, 11, 0), 8.5, 5.0, roof, "MosqueDomeBase")
	var dome := _mesh_sphere(self, origin + Vector3(0, 13.0, 0), 8.0, roof, "MosqueDome")
	dome.scale = Vector3(1, 0.78, 1)
	for side in [-1.0, 1.0]:
		var x := side * 12.0
		_mesh_cylinder(self, origin + Vector3(x, 12.0, -4), 0.65, 24.0, stone, "Minaret")
		_mesh_cylinder(self, origin + Vector3(x, 24.4, -4), 0.82, 1.2, roof, "MinaretBalcony")
		_mesh_cylinder(self, origin + Vector3(x, 27.0, -4), 0.42, 4.0, stone, "MinaretTop")
		_mesh_sphere(self, origin + Vector3(x, 29.3, -4), 0.28, gold, "MinaretFinial")
	_mesh_sphere(self, origin + Vector3(0, 18.4, 0), 0.25, gold, "DomeFinial")

func _make_humanoid(parent: Node3D, shirt: Material, pants: Material, skin: Material, scale_factor := 1.0) -> Node3D:
	var rig := Node3D.new()
	rig.scale = Vector3.ONE * scale_factor
	parent.add_child(rig)
	_mesh_box(rig, Vector3(0, 1.25, 0), Vector3(0.62, 0.82, 0.34), shirt, "Torso")
	_mesh_sphere(rig, Vector3(0, 1.92, 0), 0.23, skin, "Head")
	_mesh_box(rig, Vector3(-0.38, 1.25, 0), Vector3(0.18, 0.72, 0.2), shirt, "LeftArm")
	_mesh_box(rig, Vector3(0.38, 1.25, 0), Vector3(0.18, 0.72, 0.2), shirt, "RightArm")
	_mesh_box(rig, Vector3(-0.17, 0.48, 0), Vector3(0.23, 0.72, 0.25), pants, "LeftLeg")
	_mesh_box(rig, Vector3(0.17, 0.48, 0), Vector3(0.23, 0.72, 0.25), pants, "RightLeg")
	_mesh_box(rig, Vector3(-0.17, 0.1, -0.07), Vector3(0.26, 0.18, 0.42), _mat(Color(0.12,0.13,0.15)), "LeftShoe")
	_mesh_box(rig, Vector3(0.17, 0.1, -0.07), Vector3(0.26, 0.18, 0.42), _mat(Color(0.12,0.13,0.15)), "RightShoe")
	return rig

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, -0.17, 3)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.9
	collision.shape = capsule
	collision.position.y = 0.95
	player.add_child(collision)
	player_visual = _make_humanoid(player, _mat(Color(0.07,0.22,0.55)), _mat(Color(0.07,0.08,0.10)), _mat(Color(0.68,0.48,0.34)))
	add_child(player)

func _make_car_visual(parent: Node3D, paint: Material) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	_mesh_box(root, Vector3(0, 0.72, 0), Vector3(2.05, 0.65, 4.25), paint, "CarBody")
	_mesh_box(root, Vector3(0, 1.22, -0.22), Vector3(1.72, 0.78, 2.12), _mat(Color(0.08,0.13,0.18), 0.18, 0.3), "Cabin")
	_mesh_box(root, Vector3(0, 1.23, -0.24), Vector3(1.78, 0.06, 2.18), _mat(Color(0.06,0.08,0.10), 0.22), "Roof")
	_mesh_box(root, Vector3(0, 0.78, -2.15), Vector3(1.8, 0.22, 0.08), _mat(Color(0.95,0.12,0.08), 0.25), "RearLights")
	_mesh_box(root, Vector3(0, 0.78, 2.15), Vector3(1.8, 0.22, 0.08), _mat(Color(0.95,0.88,0.62), 0.25), "HeadLights")
	_mesh_box(root, Vector3(0, 1.75, -0.1), Vector3(0.72, 0.22, 0.38), _mat(Color(0.98,0.76,0.08)), "TaxiSign")
	_mesh_box(root, Vector3(0, 1.87, -0.1), Vector3(0.65, 0.025, 0.30), _mat(Color(0.98,0.95,0.75)), "TaxiSignTop")
	for x in [-1.02, 1.02]:
		for z in [-1.38, 1.38]:
			var wheel := _mesh_cylinder(root, Vector3(x, 0.43, z), 0.42, 0.22, _mat(Color(0.035,0.04,0.045), 0.95), "Wheel")
			wheel.rotation.z = PI * 0.5
			_mesh_cylinder(root, Vector3(x * 1.01, 0.43, z), 0.21, 0.235, _mat(Color(0.48,0.50,0.52), 0.25, 0.75), "Rim").rotation.z = PI * 0.5
	return root

func _build_car() -> void:
	car = CharacterBody3D.new()
	car.name = "YellowTaxi"
	car.position = Vector3(4.2, -0.17, 3.0)
	var collision := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.1, 1.6, 4.4)
	collision.shape = box
	collision.position.y = 0.8
	car.add_child(collision)
	car_visual = _make_car_visual(car, _mat(Color(0.98,0.58,0.035), 0.3, 0.25))
	add_child(car)

func _build_people_and_traffic() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 8911
	for i in range(24):
		var person := Node3D.new()
		person.position = Vector3(rng.randf_range(-125,125), 0, rng.randf_range(-130,130))
		var colors := [Color(0.16,0.31,0.55), Color(0.42,0.18,0.22), Color(0.24,0.34,0.25), Color(0.38,0.31,0.22)]
		_make_humanoid(person, _mat(colors[i % colors.size()]), _mat(Color(0.12,0.13,0.16)), _mat(Color(0.58,0.40,0.29)), 0.82)
		add_child(person)
		pedestrian_nodes.append({"node": person, "origin": person.position, "phase": rng.randf_range(0,TAU), "speed": rng.randf_range(0.45,1.15)})
	for i in range(9):
		var traffic_car := CharacterBody3D.new()
		traffic_car.name = "CityTraffic_%02d" % i
		var lane := -1.0 if i % 2 == 0 else 1.0
		traffic_car.position = Vector3(rng.randf_range(-140,140), 0.15, lane * 3.2 + float((i % 3) - 1) * 45.0)
		var colors2 := [Color(0.72,0.75,0.78), Color(0.12,0.16,0.20), Color(0.60,0.12,0.08), Color(0.12,0.28,0.52)]
		var vis := _make_car_visual(traffic_car, _mat(colors2[i % colors2.size()], 0.32, 0.2))
		vis.scale = Vector3(0.72,0.72,0.72)
		add_child(traffic_car)
		traffic_nodes.append({"node":traffic_car,"speed":rng.randf_range(5.0,10.0) * lane,"lane":lane})
	for i in range(3):
		var cop := Node3D.new()
		cop.position = Vector3(-18.0 + i * 18.0, 0, -32.0)
		_make_humanoid(cop, _mat(Color(0.04,0.09,0.22)), _mat(Color(0.035,0.05,0.12)), _mat(Color(0.62,0.45,0.34)), 0.9)
		_mesh_box(cop, Vector3(0,2.16,0), Vector3(0.42,0.12,0.22), _mat(Color(0.12,0.32,0.95),0.25), "PoliceBeacon")
		add_child(cop)
		police_nodes.append({"node":cop,"phase":float(i)*1.9})

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.name = "ThirdPersonCamera"
	camera.current = true
	camera.fov = 72
	add_child(camera)
	camera.global_position = Vector3(0, 5, 21)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(root)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 16)
	panel.custom_minimum_size = Vector2(330, 110)
	var vbox := VBoxContainer.new()
	panel.add_child(vbox)
	ui_label = Label.new()
	ui_label.add_theme_font_size_override("font_size", 19)
	ui_label.text = "İSTANBUL CITY  •  CAN 100  •  ₺5.000"
	vbox.add_child(ui_label)
	mission_label = Label.new()
	mission_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_label.custom_minimum_size.y = 54
	mission_label.text = "GÖREV  •  Şehri keşfet"
	vbox.add_child(mission_label)
	root.add_child(panel)
	var map_panel := Panel.new()
	map_panel.anchor_left = 1
	map_panel.anchor_right = 1
	map_panel.offset_left = -154
	map_panel.offset_right = -18
	map_panel.offset_top = 18
	map_panel.offset_bottom = 154
	root.add_child(map_panel)
	var map_label := Label.new()
	map_label.text = "N\n┌─────────┐\n│  ┌──┐   │\n│  │● │   │\n│  └──┘   │\n└─────────┘\nİSTANBUL"
	map_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	map_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	map_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map_panel.add_child(map_label)
	var joystick_hint := Label.new()
	joystick_hint.text = "◉"
	joystick_hint.add_theme_font_size_override("font_size", 62)
	joystick_hint.position = Vector2(52, -154)
	joystick_hint.anchor_top = 1
	joystick_hint.anchor_bottom = 1
	joystick_hint.modulate = Color(1,1,1,0.65)
	root.add_child(joystick_hint)
	var joystick_text := Label.new()
	joystick_text.text = "HAREKET"
	joystick_text.position = Vector2(50, -62)
	joystick_text.anchor_top = 1
	joystick_text.anchor_bottom = 1
	joystick_text.add_theme_font_size_override("font_size", 12)
	root.add_child(joystick_text)
	_add_button(root, "KOŞ", Vector2(-108,-225), "sprint")
	_add_button(root, "EĞİL", Vector2(-108,-165), "crouch")
	_add_button(root, "ZIPLA", Vector2(-108,-105), "jump")
	_add_button(root, "ETKİLEŞİM", Vector2(-132,-45), "interact")
	_add_button(root, "GÖREV", Vector2(-132,-285), "mission")
	speed_label = Label.new()
	speed_label.anchor_left = 1
	speed_label.anchor_right = 1
	speed_label.anchor_top = 1
	speed_label.anchor_bottom = 1
	speed_label.offset_left = -230
	speed_label.offset_right = -18
	speed_label.offset_top = -60
	speed_label.offset_bottom = -18
	speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	speed_label.add_theme_font_size_override("font_size", 22)
	root.add_child(speed_label)
	var hint := Label.new()
	hint.text = "Sol alanda sürükle: hareket / kamera için sağ üst alanda sürükle"
	hint.anchor_top = 1
	hint.anchor_bottom = 1
	hint.offset_left = 18
	hint.offset_right = 520
	hint.offset_top = -28
	hint.offset_bottom = -6
	hint.add_theme_font_size_override("font_size", 12)
	hint.modulate = Color(1,1,1,0.75)
	root.add_child(hint)
	# Vehicle controls, hidden until entering the taxi.
	_add_button(root, "GAZ", Vector2(-110,-115), "gas", true)
	_add_button(root, "FREN", Vector2(-220,-115), "brake", true)
	_add_button(root, "EL FRENİ", Vector2(-165,-185), "handbrake", true)
	_add_button(root, "ARAÇTAN İN", Vector2(-220,-255), "exit_car", true)
	_set_vehicle_ui(false)

func _add_button(root: Control, caption: String, offset: Vector2, action: String, vehicle_only := false) -> void:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size = Vector2(104, 54)
	b.anchor_left = 1
	b.anchor_right = 1
	b.anchor_top = 1
	b.anchor_bottom = 1
	b.offset_left = offset.x - 104
	b.offset_right = offset.x
	b.offset_top = offset.y - 54
	b.offset_bottom = offset.y
	b.add_theme_font_size_override("font_size", 15)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", _button_style(Color(0.08,0.13,0.22,0.82)))
	b.add_theme_stylebox_override("hover", _button_style(Color(0.16,0.30,0.48,0.94)))
	b.add_theme_stylebox_override("pressed", _button_style(Color(0.78,0.47,0.08,0.95)))
	root.add_child(b)
	b.button_down.connect(func(): _button_down(action))
	b.button_up.connect(func(): _button_up(action))
	touch_buttons[action] = {"button":b,"vehicle":vehicle_only}

func _button_style(color: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.border_color = Color(0.72,0.83,0.96,0.8)
	s.set_border_width_all(2)
	s.set_corner_radius_all(14)
	return s

func _button_down(action: String) -> void:
	match action:
		"sprint": sprinting = true
		"crouch": crouching = true
		"jump": jumping = true
		"interact": _interact()
		"mission": _advance_mission()
		"gas": throttle = 1.0
		"brake": throttle = -1.0
		"handbrake": handbrake = true
		"exit_car": _exit_car()

func _button_up(action: String) -> void:
	match action:
		"sprint": sprinting = false
		"crouch": crouching = false
		"jump": jumping = false
		"gas", "brake": throttle = 0.0
		"handbrake": handbrake = false

func _set_vehicle_ui(enabled: bool) -> void:
	for key in touch_buttons:
		var entry: Dictionary = touch_buttons[key]
		var b: Button = entry["button"]
		if entry["vehicle"]:
			b.visible = enabled
		else:
			b.visible = not enabled

func _input(event: InputEvent) -> void:
	var view := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			last_touch = event.position
			if event.position.x < view.x * 0.48 and event.position.y > view.y * 0.52:
				joystick_touch_index = event.index
				var center := Vector2(118, view.y - 118)
				joystick = (event.position - center) / 72.0
				joystick = joystick.limit_length(1.0)
			else:
				camera_touch_index = event.index
				camera_drag = true
		else:
			if event.index == joystick_touch_index:
				joystick = Vector2.ZERO
				joystick_touch_index = -1
			if event.index == camera_touch_index:
				camera_drag = false
				camera_touch_index = -1
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch_index:
			var center := Vector2(118, view.y - 118)
			joystick = ((event.position - center) / 72.0).limit_length(1.0)
		elif event.index == camera_touch_index and camera_drag:
			var diff := event.position - last_touch
			camera_yaw -= diff.x * 0.004
			camera_pitch = clamp(camera_pitch - diff.y * 0.0025, -0.48, 0.12)
			last_touch = event.position
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		camera_drag = event.pressed
	elif event is InputEventMouseMotion and camera_drag:
		camera_yaw -= event.relative.x * 0.004
		camera_pitch = clamp(camera_pitch - event.relative.y * 0.0025, -0.48, 0.12)

func _update_player(delta: float) -> void:
	var input_vec := joystick
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): input_vec.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): input_vec.y += 1
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): input_vec.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): input_vec.x += 1
	input_vec = input_vec.limit_length(1.0)
	var forward := Vector3(sin(camera_yaw), 0, cos(camera_yaw))
	var right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
	var direction := right * input_vec.x + forward * input_vec.y
	var speed := 1.9 if crouching else (SPRINT_SPEED if sprinting else PLAYER_SPEED)
	player.velocity.x = direction.x * speed
	player.velocity.z = direction.z * speed
	if jumping and player.is_on_floor():
		player.velocity.y = 7.0
	player.velocity.y -= 20.0 * delta
	player.move_and_slide()
	player.position.x = clamp(player.position.x, -CITY_LIMIT, CITY_LIMIT)
	player.position.z = clamp(player.position.z, -CITY_LIMIT, CITY_LIMIT)
	if direction.length() > 0.08:
		player_visual.rotation.y = lerp_angle(player_visual.rotation.y, atan2(direction.x, direction.z), delta * 10.0)
		var stride := sin(clock * (12.0 if sprinting else 8.0)) * 0.22
		player_visual.get_node("LeftLeg").rotation.x = stride
		player_visual.get_node("RightLeg").rotation.x = -stride
		player_visual.get_node("LeftArm").rotation.x = -stride * 0.8
		player_visual.get_node("RightArm").rotation.x = stride * 0.8
	else:
		for part in ["LeftLeg","RightLeg","LeftArm","RightArm"]:
			player_visual.get_node(part).rotation.x = move_toward(player_visual.get_node(part).rotation.x, 0.0, delta * 3.0)
	player_visual.scale.y = 0.78 if crouching else 1.0

func _update_car(delta: float) -> void:
	var steer_input := joystick.x
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): steer_input -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): steer_input += 1
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): throttle = 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): throttle = -1
	if throttle > 0:
		car_speed = move_toward(car_speed, CAR_MAX_SPEED, CAR_ACCEL * delta)
	elif throttle < 0:
		car_speed = move_toward(car_speed, -8.0 if car_speed < 1 else 0.0, 27.0 * delta)
	else:
		car_speed = move_toward(car_speed, 0.0, (12.0 if handbrake else 3.5) * delta)
	if handbrake:
		car_speed = move_toward(car_speed, 0.0, 20.0 * delta)
	car_yaw -= steer_input * clamp(abs(car_speed) / 12.0, 0.18, 1.0) * 1.55 * delta * sign(car_speed if abs(car_speed) > 0.1 else 1.0)
	car.rotation.y = car_yaw
	var forward := Vector3(sin(car_yaw), 0, cos(car_yaw))
	var old_pos := car.global_position
	car.velocity = forward * car_speed
	car.move_and_slide()
	if car.get_slide_collision_count() > 0:
		car_speed *= -0.18
	car.position.x = clamp(car.position.x, -CITY_LIMIT, CITY_LIMIT)
	car.position.z = clamp(car.position.z, -CITY_LIMIT, CITY_LIMIT)
	player.global_position = car.global_position
	player.rotation.y = car_yaw
	if abs(car_speed) < 0.1:
		car_speed = 0.0

func _update_people(delta: float) -> void:
	for entry in pedestrian_nodes:
		var n: Node3D = entry["node"]
		var origin: Vector3 = entry["origin"]
		var phase: float = entry["phase"]
		var speed: float = entry["speed"]
		n.position.x = origin.x + sin(clock * 0.35 + phase) * 4.0
		n.position.z = origin.z + cos(clock * 0.27 + phase) * 2.5
		n.rotation.y = atan2(cos(clock * 0.35 + phase), -sin(clock * 0.27 + phase))
		var step := sin(clock * speed * 5.0 + phase) * 0.18
		n.get_node("LeftLeg").rotation.x = step
		n.get_node("RightLeg").rotation.x = -step

func _update_traffic(delta: float) -> void:
	for entry in traffic_nodes:
		var n: CharacterBody3D = entry["node"]
		var speed: float = entry["speed"]
		n.position.x += speed * delta
		if n.position.x > 165: n.position.x = -165
		if n.position.x < -165: n.position.x = 165
		n.rotation.y = PI * 0.5 if speed > 0 else -PI * 0.5

func _update_police(delta: float) -> void:
	for entry in police_nodes:
		var cop: Node3D = entry["node"]
		if wanted > 0:
			var target := player.global_position + Vector3(sin(clock + entry["phase"]) * 5.0, 0, cos(clock + entry["phase"]) * 5.0)
			cop.position = cop.position.move_toward(target, delta * 5.0)
		else:
			cop.position.x += sin(clock * 0.3 + entry["phase"]) * delta * 0.35

func _update_camera(delta: float) -> void:
	var target := car.global_position if driving else player.global_position
	var distance := 8.2 if driving else 6.4
	var height := 3.1 if driving else (3.0 if not crouching else 2.3)
	var yaw := car_yaw if driving else camera_yaw
	var offset := Vector3(sin(yaw) * distance, height, cos(yaw) * distance)
	var desired := target + offset
	camera.global_position = camera.global_position.lerp(desired, 1.0 - exp(-delta * 7.5))
	camera.look_at(target + Vector3(0, 1.25, 0), Vector3.UP)

func _interact() -> void:
	if driving:
		_exit_car()
		return
	if player.global_position.distance_to(car.global_position) < 5.0:
		driving = true
		car.global_position = player.global_position + Vector3(0.8,0,0)
		car_yaw = player.rotation.y
		car.rotation.y = car_yaw
		player.visible = false
		_set_vehicle_ui(true)
		mission_text = "Taksiyle şehri keşfet • GAZ ile ilerle"

func _exit_car() -> void:
	if not driving: return
	driving = false
	player.visible = true
	player.global_position = car.global_position + Vector3(2.1,0,0)
	player.rotation.y = car_yaw
	car_speed = 0
	throttle = 0
	_set_vehicle_ui(false)
	mission_text = "Şehri keşfet • Görev noktasına ilerle"

func _advance_mission() -> void:
	if mission_stage == 0:
		mission_stage = 1
		wanted = 1
		mission_text = "Görev: Sahil meydanındaki sarı işarete ulaş"
	elif mission_stage == 1:
		mission_text = "Görev sürüyor • İşaretli meydana ulaş"
	elif mission_stage == 2:
		mission_text = "Görev tamamlandı • ₺1.500 kazandın"

func _update_mission() -> void:
	if mission_stage == 0 and player.global_position.distance_to(Vector3(0,0,3)) < 7:
		mission_text = "Sarı taksiye yaklaş ve ETKİLEŞİM'e bas"
	if mission_stage == 1 and player.global_position.distance_to(Vector3(0,0,-88)) < 10:
		mission_stage = 2
		money += 1500
		mission_text = "Görev tamamlandı! ₺1.500 kazandın"
		wanted = 0

func _update_hud() -> void:
	if not is_instance_valid(ui_label): return
	ui_label.text = "İSTANBUL CITY  •  CAN %d  •  ₺%s  •  %s" % [int(health), _format_money(money), "ARAÇTA" if driving else "YAYA"]
	mission_label.text = "GÖREV  •  " + mission_text
	speed_label.text = ("%d km/sa" % int(abs(car_speed) * 3.6)) if driving else ("ARAMA: %d" % wanted)

func _format_money(value: int) -> String:
	var s := str(value)
	var out := ""
	while s.length() > 3:
		out = "." + s.substr(s.length() - 3, 3) + out
		s = s.substr(0, s.length() - 3)
	return s + out
