# İSTANBUL CITY — Godot 4 Açık Dünya

Bu paket, Android hedefli Godot 4 projesidir. C++/Android Studio prototipinden ayrı, gerçek bir Godot 3B sahnesi olarak kurulmuştur.

## İçerik
- Üçüncü şahıs karakter hareketi, zıplama, koşma ve eğilme
- Kamera takibi ve dokunmatik kamera döndürme
- Sarı taksiye binme/inme ve gaz-fren-el freni kontrolleri
- Basit sürüş fiziği ve çarpışma
- Izgara yollar, şerit çizgileri, kaldırımlar, binalar, pencereler, dükkân cepheleri, parklar, ağaçlar, sokak lambaları
- Cami ve minarelerden oluşan şehir simgesi
- Yürüyen yayalar, hareketli trafik ve arama seviyesi açılınca yaklaşan polisler
- Görev hedefi, para ve can arayüzü
- Mobil uyumlu Compatibility Renderer (OpenGL ES)

## Çalıştırma
1. Godot 4.3 veya daha yeni Godot 4 sürümünü aç.
2. `project.godot` dosyasını içe aktar.
3. F6/F5 ile çalıştır.
4. Bilgisayarda WASD/ok tuşlarıyla yürü; sağ fare tuşuyla kamerayı döndür. E ile araca bin/ in.
5. Telefonda sol alt bölge hareket joystick'i; sağ taraftaki düğmeler aksiyonları yönetir. Araç kontrolleri araca binince görünür.

## Android APK alma
- Godot'ta **Editor > Manage Export Templates** bölümünden aynı Godot sürümünün export templates paketini kur.
- Android SDK/JDK yollarını **Editor Settings > Export > Android** bölümünde ayarla.
- **Project > Export > Add... > Android** ile dışa aktarma profili ekle ve APK üret.
- Bu ZIP kaynak projedir; içinde önceden derlenmiş APK veya export template bulunmaz.

## Performans
Renderer `gl_compatibility` olarak ayarlanmıştır. Bu, Android'de geniş cihaz desteği için seçildi; C53'te 60 FPS garantisi değildir. İlk performans denemesinde gölge kalitesi, görünür mesafe ve NPC sayısı azaltılabilir.

## Sınırlar — dürüst not
Bu, oynanabilir bir 3B açık dünya başlangıç oyunu/prototipidir; GTA San Andreas/5/6 ölçeğinde içerik değildir. Araç ve insan modelleri şu an kodla oluşturulan düşük poligonlu geçici modellerdir. Gerçekçi lisanslı 3B varlıklar, sesler, büyük görev zincirleri, kayıt sistemi, gelişmiş trafik kuralları ve gerçek cihaz testi henüz eklenmemiştir. Godot çalıştırıcısı bu ortamda mevcut olmadığından proje burada motor içinde derlenip doğrulanamamıştır.

## Kontroller
- Yaya: Sol alt sanal joystick veya WASD/oklar; KOŞ, EĞİL, ZIPLA.
- Etkileşim: ETKİLEŞİM düğmesi; taksinin yakınında araca binersin.
- Araç: Sol joystick ile yön, GAZ/FREN ile hız, EL FRENİ ile duruş; ARAÇTAN İN ile çıkış.
- Kamera: Ekranın sağ tarafında sürükleme; bilgisayarda sağ fare tuşuyla sürükleme.
- Görev: GÖREV düğmesiyle hedef metnini görüntüle.
