# BlockCraft Mobile — Release 0.3

Godot 4.3 projesi. Kaynak kodu tek ZIP içindedir.

## Açma ve Android APK
1. Godot 4.3 ile `project.godot` dosyasını aç.
2. Godot 4.3 Android export templates kur.
3. Android SDK ve Java SDK yollarını Editor Settings > Export > Android bölümünde ayarla.
4. Project > Export > Android > Export Project ile APK üret.

Export preset ARM64 seçilidir. APK imzalama/SDK/template dosyaları ZIP'e dahil değildir. Bu nedenle ZIP tek başına doğrudan APK değildir.

## Release 0.3 özellik kapsamı
Bu sürüm 100 maddelik özellik paketini içerir. Bazı maddeler çalışan sistem, bazıları temel altyapı/veri sınıfı veya sonraki sürüme ayrılmış prototip olarak bulunur. Örneğin Nether/End seçimi şimdilik boyut kimliği/ışınlanma prototipidir; ayrı dünya geometrisi ve Ender Dragon savaşı tamamlanmış değildir. Can ve açlık sayaçları vardır ancak açlık hasar döngüsü henüz tamamlanmamıştır. İnek ve zombi prototip varlıkları bulunur; gelişmiş animasyon/loot sistemi yoktur. Sabit 60 FPS garanti edilmez.

### 100 maddelik özellik listesi
001. Yeni dünya tohumu
002. Dünya adı
003. Otomatik kayıt
004. Manuel kayıt
005. Yükseklik haritası
006. Mağara gürültüsü
007. Maden dağılımı
008. Kum katmanı
009. Ana kaya
010. Chunk verisi
011. Chunk sınır yenileme
012. Yüzey birleştirme
013. Görünür yüz filtreleme
014. Blok seçimi
015. Blok kırma
016. Blok koyma
017. Blok düşürme sayacı
018. Hotbar
019. Envanter
020. Eşya yığını
021. Creative modu
022. Survival modu
023. Uçuş
024. Koşma
025. Zıplama
026. Can puanı
027. Açlık puanı
028. Can yenileme
029. Hasar alma
030. Ölüm/yeniden doğma
031. Gece-gündüz döngüsü
032. Güneş ışığı
033. Gerçek zamanlı gölge
034. Prosedürel gökyüzü
035. Sis ayarı
036. Parlaklık ayarı
037. Ses seviyesi ayarı
038. Görüş mesafesi ayarı
039. Dokunmatik arayüz
040. Bakış sürükleme
041. Sanal yön tuşları
042. Eylem tuşları
043. Sohbet penceresi
044. Sohbet geçmişi
045. Komut ayrıştırıcı
046. Yardım komutu
047. Oyun modu komutu
048. Işınlanma komutu
049. Eşya verme komutu
050. Skor tablosu
051. Kazılan blok sayacı
052. Skor puanı
053. Öldürme sayacı
054. Konum göstergesi
055. Hızlı blok seçimi
056. Kayıt dosyası JSON
057. Kayıt yükleme
058. Kayıt sürüm alanı
059. Dünya dışa aktarma verisi
060. Dünya içe aktarma verisi
061. Craft tarif kataloğu
062. Tahta üretimi
063. Çubuk üretimi
064. Çalışma masası tarifi
065. Meşale tarifi
066. Taş tuğla tarifi
067. Demir külçe tarifi
068. Elmas blok tarifi
069. Tarif doğrulama
070. Üretim sonucu bildirimi
071. Zombi varlık sınıfı
072. İnek varlık sınıfı
073. Mob can alanı
074. Mob takip davranışı
075. Mob yakın saldırı davranışı
076. Mob pasif dolaşma
077. Mob düşürme verisi
078. Mob doğma noktası
079. Gündüz/gece doğma katsayısı
080. Mob sayısı sınırı
081. Nether boyutu kimliği
082. End boyutu kimliği
083. Boyut geçiş altyapısı
084. Portal tetik alanı
085. Ender Dragon varlık sınıfı
086. Boss can göstergesi
087. Boss arena verisi
088. Boss ödül alanı
089. Başarım kataloğu
090. Görev kataloğu
091. Ses olay kataloğu
092. Parçacık olay kataloğu
093. Blok kırılma efekti
094. Blok koyma efekti
095. Su blok malzemesi
096. Lav emisyonu
097. 16x16 piksel dokular
098. Uygulama simgesi kaynağı
099. Android ARM64 profili
100. GL Compatibility mobil render

## Kontroller
WASD hareket, Space zıplama, Shift koşma, sağ fare tuşu + fare bakış. Mobilde sol yön düğmeleri, sağ eylem düğmeleri ve ekranın sağ tarafında sürükleyerek bakış.

## Komutlar
`/help`, `/gamemode creative`, `/gamemode survival`, `/tp x y z`, `/give diamond`, `/time set day`, `/time set night`, `/seed`, `/spawn`, `/dimension nether`, `/dimension end`, `/craft planks`

## Release 0.3 — Eşya kataloğu ve üretim
- `data/items.json`: 500 ayrı eşya kaydı; eşya kodu, Türkçe adı, kategorisi ve üretilebilirlik bilgisi.
- `data/recipes.json`: katalogdaki üretilebilir eşyaların tarifleri.
- `/items` tüm kataloğu listeler; `/items maden` gibi aramalarla filtreler.
- `/recipes` üretim tariflerini listeler.
- `/craft eşya_kodu` malzemeleri kontrol ederek üretim yapar.
- `/give eşya_kodu` test amacıyla 16 adet verir. Tariflerde kullanılan ara malzemeler envanterde ayrı kimliklerle tutulur.
- Yeni envanter kayıtları otomatik kayda dahil edilir.

Not: 500 eşyalık katalog ve tarif altyapısı oyuna eklenmiştir; bu, Minecraft'ın tüm 500 eşyasının 3B modelinin, özel animasyonunun, davranışının veya her blok için ayrı dokusunun tamamlandığı anlamına gelmez. Birçok eşya şu an envanter/katalog/üretim verisi seviyesindedir. Fırın eritme, iksir demleme, büyü, zırh giyme ve tüm eşya etkileşimleri henüz tamamlanmamıştır. Bazı tarifler temel prototip tarifleridir ve Minecraft'ın birebir tarif doğruluğu garanti edilmez.

\n## Release 0.4 ekleri
- Daha belirgin tepe ve dağ oluşumu.
- Deneme köy evleri, kırık portal, yeraltı stronghold odası ve antik şehir alanı.
- Antik şehir koordinatlarında Warden benzeri güçlü düşman.
- F5 ile birinci/üçüncü şahıs kamera geçişi.
- F3 ile koordinat ve chunk bilgisi.
- Sol üstte FPS göstergesi.
- Envanter penceresinde karakter renkli önizlemesi ve eşya listesi.

Not: Bu yapılar prosedürel prototiptir; Minecraft'ın tüm yapı şablonları, sandık ganimetleri, sculk mekanikleri, Warden'ın ses/titreşim algısı ve gerçek oyuncu skin dosyası sistemi henüz uygulanmış değildir. Godot editöründe derleme/çalıştırma testi yapılmamıştır.
