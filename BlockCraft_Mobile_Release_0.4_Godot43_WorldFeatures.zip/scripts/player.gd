extends CharacterBody3D
class_name BlockCraftPlayer

var walk_speed := 5.2
var sprint_speed := 8.0
var jump_velocity := 6.4
var gravity := 18.0
var flying := false
var creative := false
var health := 20.0
var hunger := 20.0
var camera: Camera3D
var pitch := 0.0
var third_person := false
var avatar: Node3D
var camera_pivot: Node3D

func _ready() -> void:
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.34
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    add_child(collision)
    var head := Node3D.new()
    head.name = "Head"
    head.position.y = 1.62
    add_child(head)
    camera_pivot = Node3D.new()
    camera_pivot.name = "CameraPivot"
    camera_pivot.position.y = 1.62
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 75.0
    camera_pivot.add_child(camera)
    camera.position = Vector3(0, 0, 0)
    avatar = Node3D.new()
    avatar.name = "Avatar"
    add_child(avatar)
    var torso := MeshInstance3D.new()
    var torso_mesh := BoxMesh.new()
    torso_mesh.size = Vector3(0.68, 0.85, 0.34)
    torso.mesh = torso_mesh
    torso.position.y = 1.05
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color("#3b8f55")
    torso.material_override = skin
    avatar.add_child(torso)
    var head_mesh := MeshInstance3D.new()
    var cube := BoxMesh.new()
    cube.size = Vector3(0.48, 0.48, 0.48)
    head_mesh.mesh = cube
    head_mesh.position.y = 1.72
    var face := StandardMaterial3D.new()
    face.albedo_color = Color("#c99469")
    head_mesh.material_override = face
    avatar.add_child(head_mesh)
    for side in [-1, 1]:
        var leg := MeshInstance3D.new()
        var leg_mesh := BoxMesh.new()
        leg_mesh.size = Vector3(0.25, 0.65, 0.28)
        leg.mesh = leg_mesh
        leg.position = Vector3(0.18 * side, 0.33, 0)
        leg.material_override = skin
        avatar.add_child(leg)
        var arm := MeshInstance3D.new()
        var arm_mesh := BoxMesh.new()
        arm_mesh.size = Vector3(0.22, 0.72, 0.25)
        arm.mesh = arm_mesh
        arm.position = Vector3(0.45 * side, 1.08, 0)
        arm.material_override = skin
        avatar.add_child(arm)
    _update_camera_mode()

func _physics_process(delta: float) -> void:
    var axis := Vector2(Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward"))
    var forward := -global_basis.z
    var right := global_basis.x
    forward.y = 0
    right.y = 0
    var direction := (right.normalized() * axis.x + forward.normalized() * axis.y).normalized()
    var speed := sprint_speed if Input.is_key_pressed(KEY_SHIFT) else walk_speed
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if flying:
        velocity.y = 4.5 if Input.is_key_pressed(KEY_SPACE) else (-4.5 if Input.is_key_pressed(KEY_CTRL) else 0.0)
    else:
        if not is_on_floor():
            velocity.y -= gravity * delta
        elif Input.is_action_just_pressed("jump"):
            velocity.y = jump_velocity
    move_and_slide()

func look(delta_pos: Vector2) -> void:
    rotate_y(-delta_pos.x * 0.003)
    pitch = clamp(pitch - delta_pos.y * 0.003, deg_to_rad(-88), deg_to_rad(88))
    camera_pivot.rotation.x = pitch

func toggle_camera() -> void:
    third_person = not third_person
    _update_camera_mode()

func _update_camera_mode() -> void:
    if not is_instance_valid(camera): return
    camera.position = Vector3(0, 0.25, 4.2) if third_person else Vector3.ZERO
    camera.rotation = Vector3.ZERO
    if is_instance_valid(avatar):
        avatar.visible = third_person

func damage(amount: float) -> void:
    health = maxf(0.0, health - amount)

func heal(amount: float) -> void:
    health = minf(20.0, health + amount)
