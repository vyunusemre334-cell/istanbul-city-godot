extends Node3D

const SAVE_FILE := "user://blockcraft_release03.json"
var RECIPES:Dictionary = {}
var ITEM_CATALOG:Dictionary = {}
var ITEM_NAMES:Dictionary = {}
const FEATURE_NAMES := [
"Yeni dünya tohumu","Dünya adı","Otomatik kayıt","Manuel kayıt","Yükseklik haritası","Mağara gürültüsü","Maden dağılımı","Kum katmanı","Ana kaya","Chunk verisi",
"Chunk sınır yenileme","Yüzey birleştirme","Görünür yüz filtreleme","Blok seçimi","Blok kırma","Blok koyma","Blok düşürme sayacı","Hotbar","Envanter","Eşya yığını",
"Creative modu","Survival modu","Uçuş","Koşma","Zıplama","Can puanı","Açlık puanı","Can yenileme","Hasar alma","Ölüm/yeniden doğma",
"Gece-gündüz döngüsü","Güneş ışığı","Gerçek zamanlı gölge","Prosedürel gökyüzü","Sis ayarı","Parlaklık ayarı","Ses seviyesi ayarı","Görüş mesafesi ayarı","Dokunmatik arayüz","Bakış sürükleme",
"Sanal yön tuşları","Eylem tuşları","Sohbet penceresi","Sohbet geçmişi","Komut ayrıştırıcı","Yardım komutu","Oyun modu komutu","Işınlanma komutu","Eşya verme komutu","Skor tablosu",
"Kazılan blok sayacı","Skor puanı","Öldürme sayacı","Konum göstergesi","Hızlı blok seçimi","Kayıt dosyası JSON","Kayıt yükleme","Kayıt sürüm alanı","Dünya dışa aktarma verisi","Dünya içe aktarma verisi",
"Craft tarif kataloğu","Tahta üretimi","Çubuk üretimi","Çalışma masası tarifi","Meşale tarifi","Taş tuğla tarifi","Demir külçe tarifi","Elmas blok tarifi","Tarif doğrulama","Üretim sonucu bildirimi",
"Zombi varlık sınıfı","İnek varlık sınıfı","Mob can alanı","Mob takip davranışı","Mob yakın saldırı davranışı","Mob pasif dolaşma","Mob düşürme verisi","Mob doğma noktası","Gündüz/gece doğma katsayısı","Mob sayısı sınırı",
"Nether boyutu kimliği","End boyutu kimliği","Boyut geçiş altyapısı","Portal tetik alanı","Ender Dragon varlık sınıfı","Boss can göstergesi","Boss arena verisi","Boss ödül alanı","Başarım kataloğu","Görev kataloğu",
"Ses olay kataloğu","Parçacık olay kataloğu","Blok kırılma efekti","Blok koyma efekti","Su blok malzemesi","Lav emisyonu","16x16 piksel dokular","Uygulama simgesi kaynağı","Android ARM64 profili","GL Compatibility mobil render"
]

var world:BlockCraftWorld
var player:BlockCraftPlayer
var ui:CanvasLayer
var chat_panel:PanelContainer
var chat_log:RichTextLabel
var chat_input:LineEdit
var scoreboard:Label
var status:Label
var inventory_label:Label
var fps_label:Label
var debug_label:Label
var inventory_panel:PanelContainer
var inventory := {"grass":64,"dirt":64,"stone":64,"wood":24,"coal":0,"iron":0,"diamond":0,"sticks":0,"planks":0,"torch":0,"wheat":0,"bread":0,"stone_bricks":0,"iron_ingot":0,"diamond_block":0}
var mode := "survival"
var selected := 1
var mined := 0
var kills := 0
var score := 0
var day_time := 0.25
var save_clock := 0.0
var world_name := "Yeni Dünya"
var dimension := "Overworld"
var mob_nodes:Array[Node3D] = []
var settings := {"view_distance":3,"brightness":1.0,"sound":0.7}
var menu_open := false
var look_id := -1

func _ready() -> void:
    _load_item_database()
    _environment()
    world = BlockCraftWorld.new()
    world.name = "World"
    add_child(world)
    player = BlockCraftPlayer.new()
    player.name = "Player"
    add_child(player)
    player.position = Vector3(8,36,8)
    _build_ui()
    _load()
    _message("[color=yellow]BlockCraft Release 0.3[/color] — /help")
    _spawn_mobs()
    _update_ui()

func _load_item_database() -> void:
    var item_file := FileAccess.open("res://data/items.json", FileAccess.READ)
    if item_file:
        var parsed = JSON.parse_string(item_file.get_as_text())
        if parsed is Array:
            for entry in parsed:
                if typeof(entry) == TYPE_DICTIONARY and entry.has("id"):
                    var iid := str(entry["id"])
                    ITEM_CATALOG[iid] = entry
                    ITEM_NAMES[iid] = str(entry.get("name", iid))
                    inventory[iid] = int(inventory.get(iid, 0))
    var recipe_file := FileAccess.open("res://data/recipes.json", FileAccess.READ)
    if recipe_file:
        var parsed_recipes = JSON.parse_string(recipe_file.get_as_text())
        if typeof(parsed_recipes) == TYPE_DICTIONARY:
            RECIPES = parsed_recipes
            # Tariflerde kullanılan ara malzemeler de envanterde tutulur.
            for recipe_id in RECIPES:
                for ingredient_id in RECIPES[recipe_id]:
                    inventory[str(ingredient_id)] = int(inventory.get(str(ingredient_id), 0))

func _item_display(iid:String) -> String:
    return str(ITEM_NAMES.get(iid, iid.replace("_", " ").capitalize()))

func _environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("#2873b8")
    sky_mat.sky_horizon_color = Color("#b8dcf4")
    sky_mat.ground_bottom_color = Color("#302b27")
    sky_mat.ground_horizon_color = Color("#a7a39a")
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#b6c9df")
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-48,-32,0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 75
    add_child(sun)

func _build_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(root)
    scoreboard = Label.new()
    scoreboard.position = Vector2(16,14)
    scoreboard.add_theme_font_size_override("font_size",18)
    scoreboard.add_theme_color_override("font_color",Color.WHITE)
    scoreboard.add_theme_color_override("font_shadow_color",Color.BLACK)
    scoreboard.add_theme_constant_override("shadow_offset_x",2)
    scoreboard.add_theme_constant_override("shadow_offset_y",2)
    root.add_child(scoreboard)
    fps_label = Label.new()
    fps_label.position = Vector2(16, 112)
    fps_label.add_theme_font_size_override("font_size", 17)
    fps_label.add_theme_color_override("font_color", Color("#aaffaa"))
    root.add_child(fps_label)
    debug_label = Label.new()
    debug_label.position = Vector2(16, 136)
    debug_label.add_theme_font_size_override("font_size", 15)
    debug_label.add_theme_color_override("font_color", Color("#ffffff"))
    debug_label.visible = false
    root.add_child(debug_label)
    status = Label.new()
    status.position = Vector2(16,160)
    status.add_theme_font_size_override("font_size",20)
    status.add_theme_color_override("font_color",Color("#ffe8b3"))
    root.add_child(status)
    inventory_label = Label.new()
    inventory_label.position = Vector2(16,194)
    inventory_label.add_theme_font_size_override("font_size",15)
    inventory_label.add_theme_color_override("font_color",Color.WHITE)
    root.add_child(inventory_label)
    var cross := Label.new()
    cross.text = "+"
    cross.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    cross.position = Vector2(-8,-18)
    cross.add_theme_font_size_override("font_size",28)
    root.add_child(cross)
    var hotbar := HBoxContainer.new()
    hotbar.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    hotbar.position = Vector2(-230,-72)
    hotbar.add_theme_constant_override("separation",4)
    root.add_child(hotbar)
    var names := ["Çim","Toprak","Taş","Odun","Kum"]
    var ids := [1,2,3,4,9]
    for i in range(5):
        var b := Button.new()
        b.text = names[i]
        b.custom_minimum_size = Vector2(86,48)
        b.pressed.connect(_select_block.bind(ids[i]))
        hotbar.add_child(b)
    var actions := VBoxContainer.new()
    actions.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    actions.position = Vector2(-176,-260)
    actions.add_theme_constant_override("separation",6)
    root.add_child(actions)
    _button(actions,"Zıpla",_jump)
    _button(actions,"Kır",_break_block)
    _button(actions,"Koy",_place_block)
    _button(actions,"Çanta",_inventory)
    _button(actions,"Sohbet",_toggle_chat)
    _button(actions,"Craft",_craft_menu)
    var movement := HBoxContainer.new()
    movement.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    movement.position = Vector2(18,-168)
    movement.add_theme_constant_override("separation",4)
    root.add_child(movement)
    _button(movement,"◀",func():_tap("move_left"))
    var middle := VBoxContainer.new()
    movement.add_child(middle)
    _button(middle,"▲",func():_tap("move_forward"))
    _button(middle,"▼",func():_tap("move_back"))
    _button(movement,"▶",func():_tap("move_right"))
    var save_btn := Button.new()
    save_btn.text = "Kaydet"
    save_btn.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    save_btn.position = Vector2(18,-58)
    save_btn.pressed.connect(_save)
    root.add_child(save_btn)
    var mode_btn := Button.new()
    mode_btn.text = "Mod"
    mode_btn.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    mode_btn.position = Vector2(112,-58)
    mode_btn.pressed.connect(_toggle_mode)
    root.add_child(mode_btn)
    inventory_panel = PanelContainer.new()
    inventory_panel.position = Vector2(18, 210)
    inventory_panel.size = Vector2(300, 330)
    inventory_panel.visible = false
    root.add_child(inventory_panel)
    var inv_box := VBoxContainer.new()
    inventory_panel.add_child(inv_box)
    var avatar_title := Label.new()
    avatar_title.text = "Karakterin  |  BlokCraft görünümü"
    inv_box.add_child(avatar_title)
    var avatar_preview := ColorRect.new()
    avatar_preview.custom_minimum_size = Vector2(80, 76)
    avatar_preview.color = Color("#3b8f55")
    inv_box.add_child(avatar_preview)
    var inv_title := Label.new()
    inv_title.text = "EŞYALARIN"
    inv_box.add_child(inv_title)
    var inv_contents := Label.new()
    inv_contents.name = "InventoryContents"
    inv_contents.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    inv_box.add_child(inv_contents)
    var inv_close := Button.new()
    inv_close.text = "Kapat"
    inv_close.pressed.connect(func(): inventory_panel.visible = false)
    inv_box.add_child(inv_close)
    chat_panel = PanelContainer.new()
    chat_panel.position = Vector2(18,250)
    chat_panel.size = Vector2(460,260)
    chat_panel.visible = false
    root.add_child(chat_panel)
    var chat_box := VBoxContainer.new()
    chat_panel.add_child(chat_box)
    chat_log = RichTextLabel.new()
    chat_log.bbcode_enabled = true
    chat_log.custom_minimum_size = Vector2(430,190)
    chat_box.add_child(chat_log)
    chat_input = LineEdit.new()
    chat_input.placeholder_text = "Mesaj veya komut..."
    chat_input.text_submitted.connect(_submit_chat)
    chat_box.add_child(chat_input)

func _button(parent:Node,label:String,action:Callable) -> void:
    var b := Button.new()
    b.text = label
    b.custom_minimum_size = Vector2(78,46)
    b.pressed.connect(action)
    parent.add_child(b)

func _input(event:InputEvent) -> void:
    if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        player.look(event.relative)
    elif event is InputEventScreenTouch:
        if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x*0.42:
            look_id = event.index
        elif not event.pressed and event.index == look_id:
            look_id = -1
    elif event is InputEventScreenDrag and event.index == look_id:
        player.look(event.relative)
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ENTER: _toggle_chat()
        elif event.keycode == KEY_F3: debug_label.visible = not debug_label.visible
        elif event.keycode == KEY_F5: player.toggle_camera()
        elif event.keycode == KEY_ESCAPE: _save()

func _process(delta:float) -> void:
    fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
    debug_label.text = "XYZ: %.1f / %.1f / %.1f   |   Chunk: %d, %d   |   Boyut: %s" % [player.global_position.x, player.global_position.y, player.global_position.z, floori(player.global_position.x/16.0), floori(player.global_position.z/16.0), dimension]
    day_time = fposmod(day_time + delta/900.0,1.0)
    var sun := get_node_or_null("Sun") as DirectionalLight3D
    if sun:
        sun.rotation_degrees.x = -90.0 + day_time*360.0
        sun.light_energy = 0.25 + 1.1*maxf(0.0,sin(day_time*TAU))
    save_clock += delta
    if save_clock >= 120.0:
        save_clock = 0.0
        _save(false)
    _update_ui()

func _update_ui() -> void:
    scoreboard.text = "[b]BLOCKCRAFT[/b]\n[color=#ffd75e]Skor:[/color] %d\nKazılan blok: %d\nMob yenilgisi: %d\nMod: %s\nBoyut: %s\nXYZ: %d %d %d" % [score,mined,kills,mode,dimension,int(player.position.x),int(player.position.y),int(player.position.z)]
    status.text = "♥ %d/20     Açlık %d/20     Gün %02d:%02d" % [int(player.health),int(player.hunger),int(day_time*24),int(fposmod(day_time*24*60,60))]
    inventory_label.text = "Çim %d | Toprak %d | Taş %d | Odun %d | Elmas %d" % [inventory.grass,inventory.dirt,inventory.stone,inventory.wood,inventory.diamond]
    var contents := inventory_panel.get_node_or_null("VBoxContainer/InventoryContents")
    if contents:
        var lines:PackedStringArray = []
        for iid in inventory:
            if int(inventory[iid]) > 0:
                lines.append("%s: %d" % [_item_display(str(iid)), int(inventory[iid])])
        contents.text = "\\n".join(lines.slice(0, 18))

func _select_block(id:int) -> void:
    selected = id
    _message("Seçildi: "+world.block_labels.get(id,"Blok"))

func _ray() -> Dictionary:
    var origin := player.camera.global_position
    var target := origin + -player.camera.global_basis.z*6.0
    var query := PhysicsRayQueryParameters3D.create(origin,target)
    query.exclude = [player.get_rid()]
    return get_world_3d().direct_space_state.intersect_ray(query)

func _break_block() -> void:
    var hit := _ray()
    if hit.is_empty(): return
    var cell := Vector3i(roundi((hit.position-hit.normal*0.04).x),roundi((hit.position-hit.normal*0.04).y),roundi((hit.position-hit.normal*0.04).z))
    var id := world.get_block(cell.x,cell.y,cell.z)
    if id == 0 or id == 12: return
    world.set_block(cell.x,cell.y,cell.z,0)
    mined += 1
    score += 1
    var key := {1:"grass",2:"dirt",3:"stone",4:"wood",6:"coal",7:"iron",8:"diamond",9:"sand"}.get(id,"stone")
    inventory[key] = int(inventory.get(key,0))+1
    _update_ui()

func _place_block() -> void:
    var hit := _ray()
    if hit.is_empty(): return
    var point:Vector3 = hit.position+hit.normal*0.04
    var cell := Vector3i(roundi(point.x),roundi(point.y),roundi(point.z))
    var key := {1:"grass",2:"dirt",3:"stone",4:"wood",9:"sand"}.get(selected,"grass")
    if mode == "survival":
        if int(inventory.get(key,0)) <= 0:
            _message("Bu blok envanterinde yok.")
            return
        inventory[key] -= 1
    world.set_block(cell.x,cell.y,cell.z,selected)

func _jump() -> void:
    Input.action_press("jump")
    await get_tree().create_timer(0.12).timeout
    Input.action_release("jump")

func _tap(action:String) -> void:
    Input.action_press(action)
    await get_tree().create_timer(0.2).timeout
    Input.action_release(action)

func _toggle_chat() -> void:
    chat_panel.visible = not chat_panel.visible
    if chat_panel.visible: chat_input.grab_focus()

func _submit_chat(text_value:String) -> void:
    var msg := text_value.strip_edges()
    if msg.is_empty(): return
    if msg.begins_with("/"): _command(msg)
    else: _message("[color=#b8e6ff]Oyuncu:[/color] "+msg)
    chat_input.clear()
    chat_input.grab_focus()

func _command(line:String) -> void:
    var args := line.substr(1).split(" ",false)
    if args.is_empty(): return
    match args[0].to_lower():
        "help":
            _message("/gamemode creative|survival | /tp x y z | /give item | /time set day|night | /seed | /spawn | /craft item | /items [arama] | /recipes | F3: koordinat | F5: kamera")
        "gamemode":
            if args.size()>1 and args[1] in ["creative","survival"]:
                mode=args[1]
                player.creative=mode=="creative"
                player.flying=player.creative
                _message("Oyun modu: "+mode)
            else: _message("Kullanım: /gamemode creative|survival")
        "tp":
            if args.size()>=4:
                player.global_position=Vector3(float(args[1]),float(args[2]),float(args[3]))
                _message("Işınlandın.")
            else: _message("Kullanım: /tp x y z")
        "give":
            if args.size()>1:
                var item:=args[1].to_lower()
                if ITEM_CATALOG.has(item) or inventory.has(item):
                    inventory[item]=int(inventory.get(item,0))+16
                    _message("16 adet "+_item_display(item)+" verildi.")
                    _update_ui()
                else:
                    _message("Bilinmeyen eşya. /items ile kataloğu gör.")
        "time":
            if args.size()>2:
                day_time=0.25 if args[2]=="day" else 0.78
                _message("Zaman ayarlandı.")
        "weather":
            _message("Hava durumu: "+(args[2] if args.size()>2 else "clear")+" (görsel yağış sonraki sürümde)")
        "seed":
            _message("Dünya tohumu: "+str(world.seed_value))
        "spawn":
            player.global_position=Vector3(8,36,8)
            _message("Doğma noktasına dönüldü.")
        "dimension":
            if args.size()>1 and args[1] in ["nether","end","overworld"]:
                dimension=args[1]
                player.global_position=Vector3(8,36,8)
                _message("Boyut seçildi: "+dimension+" (ayrı boyut haritası henüz prototip)")
        "craft":
            if args.size()>1: _craft(args[1])
            else: _craft_menu()
        "items":
            _list_items(args[1] if args.size()>1 else "")
        "recipes":
            _craft_menu()
        _:
            _message("Komut bulunamadı. /help")

func _message(value:String) -> void:
    if chat_log: chat_log.append_text(value+"\n")

func _toggle_mode() -> void:
    mode="creative" if mode=="survival" else "survival"
    player.creative=mode=="creative"
    player.flying=player.creative
    _message("Mod: "+mode)

func _inventory() -> void:
    inventory_panel.visible = not inventory_panel.visible
    _update_ui()

func _craft_menu() -> void:
    var craftable:Array[String] = []
    for iid in RECIPES.keys():
        craftable.append(str(iid))
    craftable.sort()
    _message("[color=yellow]Üretilebilir tarifler ("+str(craftable.size())+")[/color]")
    var shown := 0
    for iid in craftable:
        if shown >= 35:
            _message("... ve "+str(craftable.size()-shown)+" tarif daha. /craft eşya_kodu")
            break
        _message(iid+" — "+_item_display(iid))
        shown += 1

func _list_items(filter_text:String="") -> void:
    var shown := 0
    var needle := filter_text.to_lower()
    _message("[color=yellow]Eşya kataloğu: "+str(ITEM_CATALOG.size())+" eşya[/color]")
    for iid in ITEM_CATALOG.keys():
        var entry:Dictionary = ITEM_CATALOG[iid]
        var label := _item_display(str(iid))
        if needle != "" and not str(iid).contains(needle) and not label.to_lower().contains(needle) and not str(entry.get("category","")).to_lower().contains(needle):
            continue
        _message(str(iid)+" — "+label+" ("+str(entry.get("category","Diğer"))+")")
        shown += 1
        if shown >= 45:
            _message("Liste sınırı. Daha dar arama için /items kelime")
            break
    if shown == 0:
        _message("Bu aramayla eşya bulunamadı.")

func _craft(recipe:String) -> void:
    if not RECIPES.has(recipe):
        _message("Bu eşyanın üretim tarifi yok veya kod yanlış.")
        return
    var ingredients:Dictionary = RECIPES[recipe]
    for item in ingredients:
        if int(inventory.get(item,0)) < int(ingredients[item]):
            _message("Yeterli malzeme yok: "+_item_display(str(item))+" ("+str(ingredients[item])+" gerekli)")
            return
    for item in ingredients:
        inventory[item] = int(inventory.get(item,0)) - int(ingredients[item])
    inventory[recipe] = int(inventory.get(recipe,0)) + 1
    _message("[color=lightgreen]Üretildi: "+_item_display(recipe)+"[/color]")
    _update_ui()

func _spawn_mobs() -> void:
    for i in range(3):
        var cow := _make_mob("İnek",Color("#8b5d42"),false)
        cow.position=Vector3(5+i*4,26,4+i*3)
        add_child(cow)
        mob_nodes.append(cow)
    var zombie := _make_mob("Zombi",Color("#478d55"),true)
    zombie.position=Vector3(14,26,13)
    add_child(zombie)
    mob_nodes.append(zombie)
    var warden := _make_mob("Warden", Color("#123f4a"), true)
    warden.position = Vector3(96, 10, -96)
    warden.set_meta("health", 80.0)
    warden.set_meta("speed", 3.2)
    mob_nodes.append(warden)

func _make_mob(label:String,tint:Color,hostile:bool) -> Node3D:
    var mob:=CharacterBody3D.new()
    mob.name=label
    mob.set_meta("hostile",hostile)
    mob.set_meta("health",12.0 if hostile else 8.0)
    mob.set_meta("wander",randf()*TAU)
    var body:=MeshInstance3D.new()
    var mesh:=BoxMesh.new()
    mesh.size=Vector3(0.8,1.2,0.55)
    body.mesh=mesh
    var mat:=StandardMaterial3D.new()
    mat.albedo_color=tint
    body.material_override=mat
    body.position.y=0.65
    mob.add_child(body)
    var shape:=CollisionShape3D.new()
    var capsule:=CapsuleShape3D.new()
    capsule.radius=0.35
    capsule.height=1.2
    shape.shape=capsule
    shape.position.y=0.6
    mob.add_child(shape)
    return mob

func _physics_process(delta:float) -> void:
    for mob in mob_nodes:
        if not is_instance_valid(mob): continue
        var hostile:=bool(mob.get_meta("hostile",false))
        var distance:=mob.global_position.distance_to(player.global_position)
        if hostile and distance<12.0:
            var direction:Vector3=(player.global_position-mob.global_position).normalized()
            var mob_speed := float(mob.get_meta("speed", 2.0))
            mob.velocity.x=direction.x*mob_speed
            mob.velocity.z=direction.z*mob_speed
            if distance<1.6:
                player.damage(2.0*delta)
        else:
            var angle:=float(mob.get_meta("wander",0.0))+delta*0.3
            mob.set_meta("wander",angle)
            mob.velocity.x=sin(angle)*0.5
            mob.velocity.z=cos(angle)*0.5
        mob.velocity.y-=18.0*delta
        mob.move_and_slide()

func _save(show_message:bool=true) -> void:
    var data:Dictionary={
        "version":3,"world_name":world_name,"seed":world.seed_value,
        "player":[player.position.x,player.position.y,player.position.z],
        "mode":mode,"dimension":dimension,"mined":mined,"kills":kills,"score":score,
        "inventory":inventory,"chunks":world.serialize(),"time":day_time
    }
    var file:=FileAccess.open(SAVE_FILE,FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))
        if show_message: _message("[color=lightgreen]Dünya kaydedildi.[/color]")

func _load() -> void:
    if not FileAccess.file_exists(SAVE_FILE): return
    var file:=FileAccess.open(SAVE_FILE,FileAccess.READ)
    if not file: return
    var parsed=JSON.parse_string(file.get_as_text())
    if typeof(parsed)!=TYPE_DICTIONARY: return
    var data:Dictionary=parsed
    if data.has("player"): player.position=Vector3(data.player[0],data.player[1],data.player[2])
    mode=str(data.get("mode","survival"))
    dimension=str(data.get("dimension","Overworld"))
    mined=int(data.get("mined",0))
    kills=int(data.get("kills",0))
    score=int(data.get("score",0))
    day_time=float(data.get("time",0.25))
    inventory=data.get("inventory",inventory)
    world.seed_value=int(data.get("seed",world.seed_value))
    world.deserialize(data.get("chunks",{}))
    player.creative=mode=="creative"
    player.flying=player.creative
