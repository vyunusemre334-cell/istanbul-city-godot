extends Node3D
class_name BlockCraftWorld

const SX := 16
const SZ := 16
const HEIGHT := 64
const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const WOOD := 4
const LEAVES := 5
const COAL := 6
const IRON := 7
const DIAMOND := 8
const SAND := 9
const WATER := 10
const LAVA := 11
const BEDROCK := 12

var noise := FastNoiseLite.new()
var chunks: Dictionary = {}
var materials: Dictionary = {}
var seed_value := 872341
var block_labels := {1:"Çimen",2:"Toprak",3:"Taş",4:"Odun",5:"Yaprak",6:"Kömür",7:"Demir",8:"Elmas",9:"Kum",10:"Su",11:"Lav",12:"Ana kaya"}

func _ready() -> void:
    noise.seed = seed_value
    noise.frequency = 0.035
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    _create_materials()
    for x in range(-1, 2):
        for z in range(-1, 2):
            create_chunk(Vector2i(x,z))
    # Uzak yapı alanlarını da başlangıçta hazırla; /tp ile ulaşılabilir.
    for landmark_chunk in [Vector2i(3,3), Vector2i(-4,2), Vector2i(0,-6), Vector2i(6,-6)]:
        if not chunks.has(landmark_chunk):
            create_chunk(landmark_chunk)

func _create_materials() -> void:
    var colors := {
        1:["#4f8536","#6b9c43","#37672c"],2:["#805331","#986440","#674128"],
        3:["#777b80","#92969a","#62666b"],4:["#754a2b","#a87948","#56351f"],
        5:["#34753a","#4d9145","#245c30"],6:["#55585b","#272a2d","#85898b"],
        7:["#a77a58","#d3a47c","#74513a"],8:["#27b9c8","#a0f4f1","#147e91"],
        9:["#c8ae72","#e1ce91","#a88c55"],10:["#337fd0","#78b8ed","#245eaa"],
        11:["#f05b18","#ffca52","#bc2c0d"],12:["#34383e","#555a60","#25282c"]
    }
    for id in colors:
        var image := Image.create(16,16,false,Image.FORMAT_RGBA8)
        for y in range(16):
            for x in range(16):
                var noise_pixel := (x*13+y*7+int(id)*11)%19
                var palette: Array = colors[id]
                var color := Color(palette[0]) if noise_pixel < 9 else (Color(palette[1]) if noise_pixel < 14 else Color(palette[2]))
                if id == WATER: color.a = 0.72
                image.set_pixel(x,y,color)
        var texture := ImageTexture.create_from_image(image)
        var material := StandardMaterial3D.new()
        material.albedo_texture = texture
        material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
        material.roughness = 0.92
        if id == WATER:
            material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
            material.cull_mode = BaseMaterial3D.CULL_DISABLED
        if id == LAVA:
            material.emission_enabled = true
            material.emission = Color("#ff5a16")
            material.emission_energy_multiplier = 0.8
        materials[id] = material

func height_at(x:int,z:int) -> int:
    var broad := noise.get_noise_2d(x * 0.32, z * 0.32)
    var detail := noise.get_noise_2d(x, z)
    var ridge := 1.0 - absf(noise.get_noise_2d(x * 0.55 + 120.0, z * 0.55 - 80.0))
    return clampi(int(22 + detail * 7 + broad * 17 + pow(maxf(0.0, ridge), 2.0) * 24), 5, 58)

func generated_block(x:int,y:int,z:int) -> int:
    if y < 0: return BEDROCK
    if y >= HEIGHT: return AIR
    var h := height_at(x,z)
    if y > h: return AIR
    if y == h:
        return SAND if h < 12 else GRASS
    if y > h-4: return SAND if h < 12 else DIRT
    var cave := noise.get_noise_3d(x*1.7,y*1.7,z*1.7)
    if y < 11 and cave > 0.60: return DIAMOND
    if y < 25 and cave > 0.57: return IRON
    if cave > 0.63: return COAL
    return STONE

func index_of(x:int,y:int,z:int) -> int:
    return x + SX*(z + SZ*y)

func create_chunk(coord:Vector2i) -> void:
    var bytes := PackedByteArray()
    bytes.resize(SX*HEIGHT*SZ)
    for x in range(SX):
        for z in range(SZ):
            for y in range(HEIGHT):
                bytes[index_of(x,y,z)] = generated_block(coord.x*SX+x,y,coord.y*SZ+z)
    _apply_landmarks(coord, bytes)
    chunks[coord] = {"data":bytes}
    rebuild_chunk(coord)

func _write_local(bytes:PackedByteArray, wx:int, y:int, wz:int, block_id:int) -> void:
    var lx := wx - int(floor(float(wx) / SX)) * SX
    var lz := wz - int(floor(float(wz) / SZ)) * SZ
    var cx := int(floor(float(wx) / SX))
    var cz := int(floor(float(wz) / SZ))
    if cx < 0 or cz < 0: pass
    if y < 0 or y >= HEIGHT: return
    # Landmark placement is performed only by the chunk that owns this block.
    var owner := Vector2i(floori(float(wx) / SX), floori(float(wz) / SZ))
    if owner != _active_landmark_chunk: return
    bytes[index_of(lx, y, lz)] = block_id

var _active_landmark_chunk := Vector2i.ZERO

func _apply_landmarks(coord:Vector2i, bytes:PackedByteArray) -> void:
    _active_landmark_chunk = coord
    # Small village: four simple houses around a central path.
    for house in [Vector2i(48,48), Vector2i(64,48), Vector2i(48,64), Vector2i(64,64)]:
        var hx := house.x
        var hz := house.y
        var floor_y := height_at(hx, hz) + 1
        for x in range(hx, hx + 7):
            for z in range(hz, hz + 7):
                _write_local(bytes,x,floor_y,hz + (z-hz),4 if x==hx or x==hx+6 or z==hz or z==hz+6 else 5)
                for y in range(floor_y+1, floor_y+4):
                    if x==hx or x==hx+6 or z==hz or z==hz+6:
                        _write_local(bytes,x,y,z,4)
                _write_local(bytes,x,floor_y+4,z,4 if (x+z)%2==0 else 5)
        _write_local(bytes,hx+3,floor_y+1,hz,0)
        _write_local(bytes,hx+3,floor_y+2,hz,0)
        _write_local(bytes,hx+3,floor_y+1,hz+6,0)
        _write_local(bytes,hx+3,floor_y+2,hz+6,0)
    # Ruined portal, obsidian frame and scattered stone around (-64, 32).
    var py := height_at(-64,32)+1
    for y in range(py,py+6):
        _write_local(bytes,-64,y,32,12)
        _write_local(bytes,-60,y,32,12)
    for x in range(-64,-59):
        _write_local(bytes,x,py,32,12)
        _write_local(bytes,x,py+5,32,12)
    _write_local(bytes,-63,py+1,32,11)
    _write_local(bytes,-62,py+1,32,11)
    _write_local(bytes,-61,py+1,32,11)
    # Stronghold-like underground stone-brick ring at (0,-96), depth 20.
    var sy := 18
    for x in range(-5,6):
        for z in range(-101,-90):
            if abs(x)==5 or z in [-101,-91]:
                _write_local(bytes,x,sy,z,3)
                _write_local(bytes,x,sy+1,z,3)
                _write_local(bytes,x,sy+2,z,3)
            elif abs(x)<=1 and z in [-97,-96,-95]:
                _write_local(bytes,x,sy,z,8)
    # Ancient-city-like deep slate plaza at (96,-96).
    var ay := 7
    for x in range(88,105):
        for z in range(-104,-87):
            _write_local(bytes,x,ay,z,3)
            if x in [88,104] or z in [-104,-88]:
                for y in range(ay+1,ay+5):
                    _write_local(bytes,x,y,z,12)
    _active_landmark_chunk = Vector2i(999999,999999)

func get_block(x:int,y:int,z:int) -> int:
    var c := Vector2i(floori(float(x)/SX),floori(float(z)/SZ))
    if not chunks.has(c): return generated_block(x,y,z)
    return int(chunks[c].data[index_of(posmod(x,SX),y,posmod(z,SZ))])

func set_block(x:int,y:int,z:int,id:int) -> void:
    if y < 0 or y >= HEIGHT: return
    var c := Vector2i(floori(float(x)/SX),floori(float(z)/SZ))
    if not chunks.has(c): return
    chunks[c].data[index_of(posmod(x,SX),y,posmod(z,SZ))] = id
    rebuild_chunk(c)

func rebuild_chunk(c:Vector2i) -> void:
    if not chunks.has(c): return
    var node_name := "Chunk_%d_%d" % [c.x,c.y]
    var old := get_node_or_null(node_name)
    if old: old.queue_free()
    var surfaces := {}
    for id in range(1,13):
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        surfaces[id] = st
    var faces := [
        [Vector3i(0,1,0),[Vector3(0,1,0),Vector3(0,1,1),Vector3(1,1,1),Vector3(1,1,0)]],
        [Vector3i(0,-1,0),[Vector3(0,0,1),Vector3(0,0,0),Vector3(1,0,0),Vector3(1,0,1)]],
        [Vector3i(0,0,1),[Vector3(0,0,1),Vector3(1,0,1),Vector3(1,1,1),Vector3(0,1,1)]],
        [Vector3i(0,0,-1),[Vector3(1,0,0),Vector3(0,0,0),Vector3(0,1,0),Vector3(1,1,0)]],
        [Vector3i(1,0,0),[Vector3(1,0,1),Vector3(1,0,0),Vector3(1,1,0),Vector3(1,1,1)]],
        [Vector3i(-1,0,0),[Vector3(0,0,0),Vector3(0,0,1),Vector3(0,1,1),Vector3(0,1,0)]]
    ]
    var bytes:PackedByteArray = chunks[c].data
    for y in range(HEIGHT):
        for z in range(SZ):
            for x in range(SX):
                var id := int(bytes[index_of(x,y,z)])
                if id == AIR: continue
                for face in faces:
                    var normal:Vector3i = face[0]
                    var nx := x+normal.x
                    var ny := y+normal.y
                    var nz := z+normal.z
                    var neighbor := AIR
                    if nx>=0 and nx<SX and ny>=0 and ny<HEIGHT and nz>=0 and nz<SZ:
                        neighbor = int(bytes[index_of(nx,ny,nz)])
                    elif ny>=0 and ny<HEIGHT:
                        neighbor = get_block(c.x*SX+nx,ny,c.y*SZ+nz)
                    if neighbor != AIR and id != WATER and id != LAVA: continue
                    var verts:Array = face[1]
                    var base := Vector3(x,y,z)
                    var st:SurfaceTool = surfaces[id]
                    var uv := [Vector2(0,0),Vector2(0,1),Vector2(1,1),Vector2(1,0)]
                    for k in [0,1,2,0,2,3]:
                        st.set_normal(Vector3(normal))
                        st.set_uv(uv[k])
                        st.add_vertex(base+verts[k])
    var chunk_node := Node3D.new()
    chunk_node.name = node_name
    chunk_node.position = Vector3(c.x*SX,0,c.y*SZ)
    add_child(chunk_node)
    for id in surfaces:
        var mesh := (surfaces[id] as SurfaceTool).commit()
        if mesh.get_surface_count()==0: continue
        var instance := MeshInstance3D.new()
        instance.mesh = mesh
        instance.material_override = materials[id]
        chunk_node.add_child(instance)
        if id != WATER and id != LAVA: instance.create_trimesh_collision()

func serialize() -> Dictionary:
    var result := {}
    for c in chunks:
        result["%d,%d" % [c.x,c.y]] = Marshalls.raw_to_base64(chunks[c].data)
    return result

func deserialize(data:Dictionary) -> void:
    for key in data:
        var pair := key.split(",")
        var c := Vector2i(int(pair[0]),int(pair[1]))
        if chunks.has(c):
            chunks[c].data = Marshalls.base64_to_raw(data[key])
            rebuild_chunk(c)
